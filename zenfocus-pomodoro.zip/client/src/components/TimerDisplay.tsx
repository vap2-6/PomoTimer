import { cn } from "@/lib/utils";

type TimerMode = "focus" | "break" | "longBreak";

interface TimerDisplayProps {
  minutes: number;
  seconds: number;
  mode: TimerMode;
  isRunning: boolean;
  completedSessions: number;
}

export default function TimerDisplay({
  minutes,
  seconds,
  mode,
  isRunning,
  completedSessions,
}: TimerDisplayProps) {
  const formatTime = (value: number) => value.toString().padStart(2, "0");
  
  const modeLabels: Record<TimerMode, string> = {
    focus: "Focus Time",
    break: "Short Break",
    longBreak: "Long Break",
  };

  return (
    <div className="flex flex-col items-center gap-6">
      <div
        className={cn(
          "px-6 py-2 rounded-full text-sm font-medium tracking-wide uppercase",
          "bg-white/20 backdrop-blur-sm border border-white/30",
          "text-white drop-shadow-lg",
          isRunning && "animate-pulse"
        )}
        data-testid="text-mode-label"
      >
        {modeLabels[mode]}
      </div>
      
      <div
        className={cn(
          "text-[8rem] md:text-[10rem] lg:text-[12rem] font-light leading-none",
          "text-white drop-shadow-[0_4px_8px_rgba(0,0,0,0.3)]",
          "tabular-nums tracking-tight"
        )}
        data-testid="text-timer-display"
      >
        {formatTime(minutes)}:{formatTime(seconds)}
      </div>
      
      <div className="flex items-center gap-2" data-testid="session-dots">
        {[1, 2, 3, 4].map((session) => (
          <div
            key={session}
            className={cn(
              "w-3 h-3 rounded-full transition-all duration-300",
              session <= completedSessions % 4 || (completedSessions > 0 && completedSessions % 4 === 0 && session <= 4)
                ? "bg-white shadow-[0_0_10px_rgba(255,255,255,0.5)]"
                : "bg-white/30 border border-white/40"
            )}
            data-testid={`session-dot-${session}`}
          />
        ))}
        {completedSessions > 0 && (
          <span className="ml-2 text-white/80 text-sm font-medium drop-shadow-md" data-testid="text-total-sessions">
            {completedSessions} completed
          </span>
        )}
      </div>
    </div>
  );
}
