import BackgroundWallpaper from "../BackgroundWallpaper";

export default function BackgroundWallpaperExample() {
  return (
    <BackgroundWallpaper
      imageUrl={null}
      isLoading={false}
      onRefresh={() => console.log("Refresh background clicked")}
    >
      <div className="flex-1 flex items-center justify-center">
        <div className="text-white text-center">
          <h1 className="text-4xl font-light mb-4">Content Goes Here</h1>
          <p className="text-white/70">Beautiful AI backgrounds will appear behind this content</p>
        </div>
      </div>
    </BackgroundWallpaper>
  );
}
