import TimerDisplay from "../TimerDisplay";

export default function TimerDisplayExample() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500">
      <TimerDisplay
        minutes={24}
        seconds={37}
        mode="focus"
        isRunning={true}
        completedSessions={2}
      />
    </div>
  );
}
