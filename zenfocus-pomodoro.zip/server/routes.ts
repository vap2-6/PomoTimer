import type { Express } from "express";
import { createServer, type Server } from "http";

const calmingThemes = [
  "peaceful+nature+landscape",
  "serene+mountain+scenery",
  "calm+ocean+waves",
  "misty+forest+morning",
  "gentle+sunset+sky",
  "tranquil+lake+reflection",
  "soft+clouds+sky",
  "zen+garden+peaceful",
  "aurora+borealis+night",
  "lavender+field+purple",
  "cherry+blossom+spring",
  "peaceful+meadow+flowers",
  "foggy+valley+mountains",
  "calm+beach+tropical",
  "starry+night+sky",
];

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get("/api/background", (_req, res) => {
    const randomTheme = calmingThemes[Math.floor(Math.random() * calmingThemes.length)];
    const timestamp = Date.now();
    const imageUrl = `https://source.unsplash.com/1920x1080/?${randomTheme}&t=${timestamp}`;
    
    res.json({ 
      imageUrl,
      theme: randomTheme.replace(/\+/g, " ")
    });
  });

  return httpServer;
}
