import { useState, useCallback, useEffect } from "react";
import { useTimer } from "@/hooks/useTimer";
import TimerDisplay from "./TimerDisplay";
import ControlPanel from "./ControlPanel";
import SettingsPanel from "./SettingsPanel";
import BackgroundWallpaper from "./BackgroundWallpaper";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";

export default function PomodoroTimer() {
  const {
    minutes,
    seconds,
    isRunning,
    mode,
    completedSessions,
    settings,
    startPause,
    reset,
    skip,
    updateSettings,
  } = useTimer();

  const [backgroundUrl, setBackgroundUrl] = useState<string | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const { toast } = useToast();

  const { data, isLoading, refetch } = useQuery<{ imageUrl: string; theme: string }>({
    queryKey: ["/api/background", refreshTrigger],
    staleTime: Infinity,
  });

  useEffect(() => {
    if (data?.imageUrl) {
      setBackgroundUrl(data.imageUrl);
    }
  }, [data]);

  const handleRefreshBackground = useCallback(() => {
    setRefreshTrigger(prev => prev + 1);
    refetch();
    toast({
      title: "Loading new background",
      description: "Finding a calming image for you...",
    });
  }, [refetch, toast]);

  useEffect(() => {
    refetch();
  }, []);

  return (
    <BackgroundWallpaper
      imageUrl={backgroundUrl}
      isLoading={isLoading}
      onRefresh={handleRefreshBackground}
    >
      <div className="absolute top-6 right-6 z-20">
        <SettingsPanel
          focusDuration={settings.focusDuration}
          breakDuration={settings.breakDuration}
          longBreakDuration={settings.longBreakDuration}
          soundEnabled={soundEnabled}
          onFocusDurationChange={(value) =>
            updateSettings({ focusDuration: value })
          }
          onBreakDurationChange={(value) =>
            updateSettings({ breakDuration: value })
          }
          onLongBreakDurationChange={(value) =>
            updateSettings({ longBreakDuration: value })
          }
          onSoundToggle={setSoundEnabled}
        />
      </div>

      <div className="flex-1 flex flex-col items-center justify-center px-4 py-12">
        <div
          className="w-full max-w-2xl mx-auto p-8 md:p-12 rounded-3xl 
            bg-white/10 backdrop-blur-xl border border-white/20
            shadow-[0_8px_32px_rgba(0,0,0,0.2)]"
          data-testid="timer-card"
        >
          <div className="flex flex-col items-center gap-8 md:gap-12">
            <TimerDisplay
              minutes={minutes}
              seconds={seconds}
              mode={mode}
              isRunning={isRunning}
              completedSessions={completedSessions}
            />

            <ControlPanel
              isRunning={isRunning}
              onStartPause={startPause}
              onReset={reset}
              onSkip={skip}
            />
          </div>
        </div>

        <p className="mt-8 text-white/60 text-sm text-center max-w-md">
          Click the refresh button to get a new calming background image
        </p>
      </div>

      <div className="absolute bottom-6 left-6 z-20">
        <div className="text-white/50 text-xs">
          <span className="font-medium">ZenFocus</span> Pomodoro Timer
        </div>
      </div>
    </BackgroundWallpaper>
  );
}
