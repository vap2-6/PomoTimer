import { useState } from "react";
import SettingsPanel from "../SettingsPanel";

export default function SettingsPanelExample() {
  const [focusDuration, setFocusDuration] = useState(25);
  const [breakDuration, setBreakDuration] = useState(5);
  const [longBreakDuration, setLongBreakDuration] = useState(15);
  const [soundEnabled, setSoundEnabled] = useState(true);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-violet-600 via-purple-600 to-fuchsia-600">
      <SettingsPanel
        focusDuration={focusDuration}
        breakDuration={breakDuration}
        longBreakDuration={longBreakDuration}
        soundEnabled={soundEnabled}
        onFocusDurationChange={setFocusDuration}
        onBreakDurationChange={setBreakDuration}
        onLongBreakDurationChange={setLongBreakDuration}
        onSoundToggle={setSoundEnabled}
      />
    </div>
  );
}
