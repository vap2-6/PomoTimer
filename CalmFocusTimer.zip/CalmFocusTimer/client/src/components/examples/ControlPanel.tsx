import ControlPanel from "../ControlPanel";

export default function ControlPanelExample() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-teal-500 via-cyan-600 to-blue-600">
      <ControlPanel
        isRunning={false}
        onStartPause={() => console.log("Start/Pause clicked")}
        onReset={() => console.log("Reset clicked")}
        onSkip={() => console.log("Skip clicked")}
      />
    </div>
  );
}
