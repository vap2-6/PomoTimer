import { cn } from "@/lib/utils";
import { RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";

interface BackgroundWallpaperProps {
  imageUrl: string | null;
  isLoading: boolean;
  onRefresh: () => void;
  children: React.ReactNode;
}

export default function BackgroundWallpaper({
  imageUrl,
  isLoading,
  onRefresh,
  children,
}: BackgroundWallpaperProps) {
  const [currentImage, setCurrentImage] = useState<string | null>(null);
  const [nextImage, setNextImage] = useState<string | null>(null);
  const [isTransitioning, setIsTransitioning] = useState(false);

  useEffect(() => {
    if (imageUrl && imageUrl !== currentImage) {
      if (!currentImage) {
        setCurrentImage(imageUrl);
      } else {
        setNextImage(imageUrl);
        setIsTransitioning(true);
        
        const timer = setTimeout(() => {
          setCurrentImage(imageUrl);
          setNextImage(null);
          setIsTransitioning(false);
        }, 2000);
        
        return () => clearTimeout(timer);
      }
    }
  }, [imageUrl, currentImage]);

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      {currentImage && (
        <div
          className={cn(
            "absolute inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-1000",
            isTransitioning ? "opacity-0" : "opacity-100"
          )}
          style={{ backgroundImage: `url(${currentImage})` }}
          data-testid="background-image-current"
        />
      )}
      
      {nextImage && (
        <div
          className={cn(
            "absolute inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-1000",
            isTransitioning ? "opacity-100" : "opacity-0"
          )}
          style={{ backgroundImage: `url(${nextImage})` }}
          data-testid="background-image-next"
        />
      )}
      
      {!currentImage && (
        <div
          className="absolute inset-0 bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500"
          data-testid="background-gradient"
        />
      )}
      
      <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-black/20 to-black/30" />
      
      <div className="relative z-10 min-h-screen flex flex-col">
        {children}
      </div>
      
      <Button
        size="icon"
        variant="ghost"
        onClick={onRefresh}
        disabled={isLoading}
        className={cn(
          "absolute bottom-6 right-6 z-20",
          "h-12 w-12 rounded-full",
          "bg-white/15 backdrop-blur-md border border-white/25",
          "text-white hover:bg-white/25"
        )}
        data-testid="button-refresh-background"
      >
        <RefreshCw className={cn("h-5 w-5", isLoading && "animate-spin")} />
      </Button>
    </div>
  );
}
