import { Button } from "@/components/ui/button";
import { Play, Pause, RotateCcw, SkipForward } from "lucide-react";
import { cn } from "@/lib/utils";

interface ControlPanelProps {
  isRunning: boolean;
  onStartPause: () => void;
  onReset: () => void;
  onSkip: () => void;
}

export default function ControlPanel({
  isRunning,
  onStartPause,
  onReset,
  onSkip,
}: ControlPanelProps) {
  return (
    <div className="flex items-center justify-center gap-4">
      <Button
        size="lg"
        variant="ghost"
        onClick={onReset}
        className={cn(
          "h-14 w-14 rounded-full",
          "bg-white/15 backdrop-blur-md border border-white/25",
          "text-white hover:bg-white/25"
        )}
        data-testid="button-reset"
      >
        <RotateCcw className="h-6 w-6" />
      </Button>
      
      <Button
        size="lg"
        onClick={onStartPause}
        className={cn(
          "h-20 w-20 rounded-full",
          "bg-white/25 backdrop-blur-md border border-white/30",
          "text-white hover:bg-white/35",
          "shadow-[0_8px_32px_rgba(0,0,0,0.2)]",
          "transition-transform active:scale-95"
        )}
        data-testid="button-start-pause"
      >
        {isRunning ? (
          <Pause className="h-8 w-8" />
        ) : (
          <Play className="h-8 w-8 ml-1" />
        )}
      </Button>
      
      <Button
        size="lg"
        variant="ghost"
        onClick={onSkip}
        className={cn(
          "h-14 w-14 rounded-full",
          "bg-white/15 backdrop-blur-md border border-white/25",
          "text-white hover:bg-white/25"
        )}
        data-testid="button-skip"
      >
        <SkipForward className="h-6 w-6" />
      </Button>
    </div>
  );
}
