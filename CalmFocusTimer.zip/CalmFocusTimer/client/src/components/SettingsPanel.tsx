import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Settings, Volume2, VolumeX } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

interface SettingsPanelProps {
  focusDuration: number;
  breakDuration: number;
  longBreakDuration: number;
  soundEnabled: boolean;
  onFocusDurationChange: (value: number) => void;
  onBreakDurationChange: (value: number) => void;
  onLongBreakDurationChange: (value: number) => void;
  onSoundToggle: (enabled: boolean) => void;
}

export default function SettingsPanel({
  focusDuration,
  breakDuration,
  longBreakDuration,
  soundEnabled,
  onFocusDurationChange,
  onBreakDurationChange,
  onLongBreakDurationChange,
  onSoundToggle,
}: SettingsPanelProps) {
  const [open, setOpen] = useState(false);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          size="icon"
          variant="ghost"
          className={cn(
            "h-12 w-12 rounded-full",
            "bg-white/15 backdrop-blur-md border border-white/25",
            "text-white hover:bg-white/25"
          )}
          data-testid="button-settings"
        >
          <Settings className="h-5 w-5" />
        </Button>
      </DialogTrigger>
      <DialogContent
        className={cn(
          "bg-black/70 backdrop-blur-xl border border-white/20",
          "text-white max-w-md"
        )}
      >
        <DialogHeader>
          <DialogTitle className="text-xl font-medium text-white">
            Timer Settings
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-8 py-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label className="text-white/90" htmlFor="focus-duration">
                Focus Duration
              </Label>
              <span className="text-lg font-medium tabular-nums" data-testid="text-focus-value">
                {focusDuration} min
              </span>
            </div>
            <Slider
              id="focus-duration"
              min={1}
              max={60}
              step={1}
              value={[focusDuration]}
              onValueChange={(value) => onFocusDurationChange(value[0])}
              className="[&_[role=slider]]:bg-white [&_[role=slider]]:border-white/50"
              data-testid="slider-focus"
            />
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label className="text-white/90" htmlFor="break-duration">
                Short Break
              </Label>
              <span className="text-lg font-medium tabular-nums" data-testid="text-break-value">
                {breakDuration} min
              </span>
            </div>
            <Slider
              id="break-duration"
              min={1}
              max={30}
              step={1}
              value={[breakDuration]}
              onValueChange={(value) => onBreakDurationChange(value[0])}
              className="[&_[role=slider]]:bg-white [&_[role=slider]]:border-white/50"
              data-testid="slider-break"
            />
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label className="text-white/90" htmlFor="long-break-duration">
                Long Break
              </Label>
              <span className="text-lg font-medium tabular-nums" data-testid="text-long-break-value">
                {longBreakDuration} min
              </span>
            </div>
            <Slider
              id="long-break-duration"
              min={5}
              max={45}
              step={1}
              value={[longBreakDuration]}
              onValueChange={(value) => onLongBreakDurationChange(value[0])}
              className="[&_[role=slider]]:bg-white [&_[role=slider]]:border-white/50"
              data-testid="slider-long-break"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center gap-3">
              {soundEnabled ? (
                <Volume2 className="h-5 w-5 text-white/80" />
              ) : (
                <VolumeX className="h-5 w-5 text-white/80" />
              )}
              <Label className="text-white/90" htmlFor="sound-toggle">
                Sound Notifications
              </Label>
            </div>
            <Switch
              id="sound-toggle"
              checked={soundEnabled}
              onCheckedChange={onSoundToggle}
              data-testid="switch-sound"
            />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
