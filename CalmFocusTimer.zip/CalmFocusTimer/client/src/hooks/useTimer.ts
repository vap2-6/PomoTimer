import { useState, useEffect, useCallback, useRef } from "react";

type TimerMode = "focus" | "break" | "longBreak";

interface TimerSettings {
  focusDuration: number;
  breakDuration: number;
  longBreakDuration: number;
}

interface UseTimerReturn {
  minutes: number;
  seconds: number;
  isRunning: boolean;
  mode: TimerMode;
  completedSessions: number;
  settings: TimerSettings;
  startPause: () => void;
  reset: () => void;
  skip: () => void;
  updateSettings: (newSettings: Partial<TimerSettings>) => void;
}

const STORAGE_KEY = "pomodoro-settings";

const clampValue = (value: number, min: number, max: number) => 
  Math.max(min, Math.min(max, value));

const getStoredSettings = (): TimerSettings => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      return {
        focusDuration: clampValue(parsed.focusDuration || 25, 1, 60),
        breakDuration: clampValue(parsed.breakDuration || 5, 1, 30),
        longBreakDuration: clampValue(parsed.longBreakDuration || 15, 5, 45),
      };
    }
  } catch (e) {
    console.error("Failed to load settings:", e);
  }
  return {
    focusDuration: 25,
    breakDuration: 5,
    longBreakDuration: 15,
  };
};

export function useTimer(): UseTimerReturn {
  const [settings, setSettings] = useState<TimerSettings>(getStoredSettings);
  const [mode, setMode] = useState<TimerMode>("focus");
  const [timeLeft, setTimeLeft] = useState(settings.focusDuration * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [completedSessions, setCompletedSessions] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const isRunningRef = useRef(isRunning);
  
  useEffect(() => {
    isRunningRef.current = isRunning;
  }, [isRunning]);

  useEffect(() => {
    audioRef.current = new Audio("https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3");
    audioRef.current.volume = 0.5;
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  }, [settings]);

  const getDuration = useCallback(
    (timerMode: TimerMode) => {
      switch (timerMode) {
        case "focus":
          return settings.focusDuration * 60;
        case "break":
          return settings.breakDuration * 60;
        case "longBreak":
          return settings.longBreakDuration * 60;
      }
    },
    [settings]
  );

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;

    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isRunning) {
      if (audioRef.current) {
        audioRef.current.play().catch(() => {});
      }
      
      if (mode === "focus") {
        const newCompleted = completedSessions + 1;
        setCompletedSessions(newCompleted);
        
        if (newCompleted % 4 === 0) {
          setMode("longBreak");
          setTimeLeft(getDuration("longBreak"));
        } else {
          setMode("break");
          setTimeLeft(getDuration("break"));
        }
      } else {
        setMode("focus");
        setTimeLeft(getDuration("focus"));
      }
      setIsRunning(false);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, timeLeft, mode, completedSessions, getDuration]);

  const startPause = useCallback(() => {
    setIsRunning((prev) => !prev);
  }, []);

  const reset = useCallback(() => {
    setIsRunning(false);
    setTimeLeft(getDuration(mode));
  }, [mode, getDuration]);

  const skip = useCallback(() => {
    setIsRunning(false);
    if (mode === "focus") {
      const newCompleted = completedSessions + 1;
      setCompletedSessions(newCompleted);
      if (newCompleted % 4 === 0) {
        setMode("longBreak");
        setTimeLeft(getDuration("longBreak"));
      } else {
        setMode("break");
        setTimeLeft(getDuration("break"));
      }
    } else {
      setMode("focus");
      setTimeLeft(getDuration("focus"));
    }
  }, [mode, completedSessions, getDuration]);

  const updateSettings = useCallback(
    (newSettings: Partial<TimerSettings>) => {
      const clampedSettings: Partial<TimerSettings> = {};
      
      if (newSettings.focusDuration !== undefined) {
        clampedSettings.focusDuration = clampValue(newSettings.focusDuration, 1, 60);
      }
      if (newSettings.breakDuration !== undefined) {
        clampedSettings.breakDuration = clampValue(newSettings.breakDuration, 1, 30);
      }
      if (newSettings.longBreakDuration !== undefined) {
        clampedSettings.longBreakDuration = clampValue(newSettings.longBreakDuration, 5, 45);
      }
      
      setSettings((prev) => {
        const updated = { ...prev, ...clampedSettings };
        
        if (!isRunningRef.current) {
          if (mode === "focus" && clampedSettings.focusDuration !== undefined) {
            setTimeLeft(clampedSettings.focusDuration * 60);
          } else if (mode === "break" && clampedSettings.breakDuration !== undefined) {
            setTimeLeft(clampedSettings.breakDuration * 60);
          } else if (mode === "longBreak" && clampedSettings.longBreakDuration !== undefined) {
            setTimeLeft(clampedSettings.longBreakDuration * 60);
          }
        }
        return updated;
      });
    },
    [mode]
  );

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return {
    minutes,
    seconds,
    isRunning,
    mode,
    completedSessions,
    settings,
    startPause,
    reset,
    skip,
    updateSettings,
  };
}
